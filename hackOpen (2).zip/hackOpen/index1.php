<html>
<?php
include "dbConfig.php";
session_start();
?>
<head>
<title>BCBSDS | Login</title>
<link rel="stylesheet" href="css/bootstrap.css"/>
</head>


<body>
<div style="    width: 420px;
    margin-left: auto;
    margin-right: auto;
    height:  auto;
    margin-top: 10px;    background-color: #f3f3f3;border-radius: 10px;padding: 20px;">
	<div style="width:200px;margin-left:auto;margin-right:auto;"><img src="img/logo b.png" style="width:200px"/></div>
	
	<center><h4>Bacolod Community-Based Services Directory System</h4></center>
	<hr>
	<form method="POST">
	
	
	<center><h3>LOGIN<h3></center>
	<?php
	if(isset($_POST['login'])){
		$uname=$_POST['uname'];
		$pword=$_POST['pword'];
		
		$res = mysqli_query($con, "Select * from barangay where brgy_uname='$uname' and brgy_pword='$pword'");
		$data1= mysqli_fetch_array($res);
		$data = mysqli_num_rows($res);
		
		if($data>0){
		$_SESSION['session_id']=$data1['brgy_id'];
		header('Location:admin.php');
		
		}else{
			?>
			<div class="alert alert-danger">
			<strong>Error!</strong> Username and Password invalid!
			</div>
			<?php
		}
		
	}
	
	?>
	<input type="text" name="uname" class="form-control" placeholder="Username"/><br>
	<input type="password" name="pword" class="form-control" placeholder="Password"/><br>
	<a href="register.php"> Register here </a>
	<center><input type="submit" name="login" value="Login" class="btn btn-success" /></center>
	
	</form>
</div>
</body>
</html>