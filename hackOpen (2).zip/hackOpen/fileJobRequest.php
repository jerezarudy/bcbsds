<?php
	
	require 'dbConfig.php';
include ( "src/NexmoMessage.php" );
	$servicePro = $_POST['userId'];
	$service = $_POST['service'];
	$customerId = $_POST['customerId'];
	$serviceId = array();
	$status = true;
	$dateStart = $_POST['dateStart'];
	$dateEnd = $_POST['dateEnd'];

	$arrSP = explode(',', $servicePro);
	$arrService = explode(',', $service);

	//get the id of the service
	$loop =count($arrSP);
	for($i=0; $i<$loop; $i++){
		$a = $arrService[$i];
		$query = "SELECT * FROM category_services WHERE service_name = '$a'";
		$exeQuery = mysqli_query($con, $query);
		
		$get =mysqli_fetch_array($exeQuery);
		array_push($serviceId, $get['id']);
	}

	//loop insertion of job request to database
	for($b=0; $b<$loop; $b++){
		$c = $arrSP[$b];
		$d = $serviceId[$b];

		$nexmo_sms = new NexmoMessage('3fd2f58d', 'jsLMlGV016O3OZSt');

		// Step 2: Use sendText( $to, $from, $message ) method to send a message. 
		$info = $nexmo_sms->sendText( '+639486502348', 'GwapoRudy', '-- BCBSDS -- You have a job request. Please open the BCBSDS application or visit and login to Http://retailboxph.com/hackOpen/index1.php');


		$query="INSERT INTO hiring_log( service_provider, customer, service_id, date_accepted, date_ended, trans_status) VALUES('$c', '$customerId', '$d', '$dateStart', '$dateEnd', 'Pending')";
		$exeQuery = mysqli_query($con, $query);
		if($exeQuery == false){
			$status = false;
		}

	}

	echo json_encode(
		array(
			'status' => $status
		)
	);

	mysqli_close($con);		
?>