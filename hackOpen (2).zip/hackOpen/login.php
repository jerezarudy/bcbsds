<!DOCTYPE html>
<html>
<head>
	<title>
		
	</title>

		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<script type="text/javascript" src="js/jquery.js"></script>
		<script type="text/javascript" src="js/bootstrap.js"></script>

		<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="css/animate.css">
		<link rel="stylesheet" type="text/css" href="css/custom.css">

</head>
<body>

	<main>
		<img src="img/applogo.png" style="width: 80%;">

		<br>
		<form id="frmLogin" method="POST">
			<input type="text" name="loginName" class="form-control" placeholder="Enter username" required>
			<input type="password" name="loginPass" class="form-control" placeholder="Enter password" required>

			<br>
			<button type="submit" class="btn btn-primary">
				Login
			</button>

		</form>

	</main>

	<script type="text/javascript" defer="true">
		$(document).ready( function(){
			$('#frmLogin').submit( function(event){
				event.preventDefault();
				var data = $(this).serialize();
				var url = 'http://localhost/hackOpen/validateLogin.php';

				$.post( url, data, function(res){

					if(res.loginStatus == true){
						window.location.href = 'sms.php';
					}else{
						alert('Credentials is invalid or mismatched!');
						$('input[name=loginPass]').val('');
					}

				}, 'json')
				.fail( function(){
					alert('An error has occured while validating credentials.')
				})

				//alert("<?php //echo'asd'?>")

			});

		})
	</script>

</body>
</html>