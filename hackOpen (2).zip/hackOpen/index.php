<html>
<?php
	include "dbConfig.php";
	session_start();
?>
<head>
	<title>BCBSDS | Login</title>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/mymain.js"></script>

	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/animate.css">
	<link rel="stylesheet" type="text/css" href="css/custom.css">
	<link rel="stylesheet" type="text/css" href="css/media.css">

</head>


<body>
	<div id="loginDivParent">
		<div style="width:200px;margin-left:auto;margin-right:auto;"><img src="img/logo b.png" style="width:200px"/></div>
		
		<center>
			<h4>Bacolod Community-Based Services Directory System</h4>
		</center>

		<hr>

		<form id="frmPhoneNumber" method="POST">
		
		
			<center><h3>Please enter Phone number<h3></center>
			
				<input type='text' name="pnumber" class="form-control" value="+639" style="text-align: center;">
				<br>

			<center>
				<button type="submit" class="btn btn-success">
					<span class="glyphicon glyphicon-log-in"></span>
					Submit
				</button>
			</center>
		
		</form>

		<form id="frmValidateCode" method="POST" style="display: none;">
			
			<h4 style="text-align: center;">
				A code has been sent to <strong id="pnumberHere"></strong>.
				Please enter verification code in the textbox below.
			</h4>
			<input type="text" name="verificationCode" class="form-control" placeholder="Enter verification code Here" style="text-align: center">
			<br>
			<button type="submit" class="btn btn-primary" style="margin: 0 auto; display: block;"> 
				Submit code
			</button>
			<br>
			<span style="font-size: 12px; display: block; width: 100%; text-align: center;">
				Did not get sms? 
				<a href="#" id="btnGetAnotherCode">Get another</a>
			</span>

		</form>


	</div>


	<script type="text/javascript" defer="true">
		
		$(document).ready( function(){

			$('#frmPhoneNumber').submit( function(event){
				event.preventDefault();

				var data = $(this).serialize();
				var url = 'checkNumber.php';
				$.post(url, data, function(res){
					if(res.id != 'null'){
						$('#pnumberHere').html($('input[name=pnumber]').val());

						$('#frmPhoneNumber').addClass('animated slideOutLeft').fadeOut();
						setTimeout( function(){
							$('#frmValidateCode').addClass('animated fadeInUp').fadeIn();
						}, 300)
						sessionStorage.setItem('userId', res.id);
					}else{
						alert('Could not find number in registry. Please check number');
					}

				}, 'json')
				.fail( function(){
					alert('An error occured during number validation.')
				});	

				
			});

			$('#frmValidateCode').submit( function(event){
				event.preventDefault();

				var data = $(this).serializeArray();
					data.push({name: 'userId', value: sessionStorage.getItem('userId')});
				var url = 'validateVerificationCode.php';
				$.post(url, data, function(res){
					if(res.status == true){
						alert('Phone number verified. Click ok to continue');
						//user has been verified
						//redirect to homepage
						window.location.href="homepage.php";

					}else{
						alert('Invalid code. Please check code again.');
					}

				}, 'json')
				.fail( function(){
					alert('An error has occured during validation of verification code.')
				})

			})

		});//end of docu ready

	</script>

</body>
</html>