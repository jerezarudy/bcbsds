<?php
	
	require 'dbConfig.php';

	$q = $_POST['filterKey'];
	$image =array();
	$name = array();
	$sex = array();
	$service =array();
	$uAddress = array();
	$wRate = array();
	$rfRate =array();
	$userId = array();


	if($q == '0'){
		$query = "SELECT * FROM s_provider INNER JOIN customer ON  s_provider.userid = customer.id INNER JOIN category_services ON s_provider.service = category_services.id";

	}else{
		$query = "SELECT * FROM s_provider INNER JOIN customer ON  s_provider.userid = customer.id INNER JOIN category_services ON s_provider.service = category_services.id WHERE s_provider.service = '$q'";
	}

	$exeQuery = mysqli_query($con, $query);
	while( $get = mysqli_fetch_array($exeQuery)){
		array_push($image, $get['user_image']);
		array_push($name, $get['f_name'].' '. $get['m_name'].'. '. $get['l_name']);
		array_push($sex, $get['sex']);
		array_push($service , $get['service_name']);
		array_push($uAddress, $get['user_address']);
		array_push($wRate, $get['work_rate']);
		array_push($rfRate, $get['gen_rate']);
		array_push($userId, $get['userid']);
	}

	echo json_encode(
		array(
			'image' => $image,
			'name' => $name,
			'sex' => $sex,
			'service' => $service,
			'address' => $uAddress,
			'wRate' => $wRate,
			'feedbackrate' => $rfRate,
			'id' => $userId
		)
	);

?>