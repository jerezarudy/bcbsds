<!DOCTYPE html>
<?php

	include "dbConfig.php";
	session_start();

?>
<html>
<head>

	<title>BCBSDS</title>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/mymain.js"></script>
	<script type="text/javascript" src="js/dataTables.min.js"></script>
	<script type="text/javascript" src="js/dataTables.responsive.min.js"></script>
	<script type="text/javascript" src="js/dataTables.rowReorder.min.js"></script>

	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/animate.css">
	<link rel="stylesheet" type="text/css" href="css/custom.css">
	<link rel="stylesheet" type="text/css" href="css/media.css">
	<link rel="stylesheet" type="text/css" href="css/dataTables.min.css">
	<link rel="stylesheet" type="text/css" href="css/responsive.dataTables.min.css">
	<link rel="stylesheet" type="text/css" href="css/rowReorder.dataTables.min.css">


	<style type="text/css">
		#btnMenu{
			background:none;
			border: none;
			color: white;
			font-size: 20px

		}
		#submenu{
			height: calc(100vh - 40px);
			width: 80vw;
			position:absolute;
			background: #333;
			bottom: 0;
			display: none;
			z-index: 1;
		}
		.divCon{
			display: none;
			width: 100%;
			padding:10px;
		}
		.divCon.active{
			display: block !important;
		}
		#docRateReview{
			list-style: none;
			padding:0;
			margin: 0;
			overflow: auto;
			height: 150px;
			margin: 10px 0;
		    border: 1px solid grey;
		    padding: 5px;
		}
		#docRateReview li{
			padding: 0;
			margin:0 ;
			display: inline-block;
		}
		#tblDivCon{
			display: block; 
			margin: 10px auto; 
			padding: 2vw; 
			width: 95%;
			border-radius: 10px;
			background: #f9f9f9;
			box-shadow: 1px 1px 20px #3c3c3c;
		}
		.withSideListActive{
			width: 70vw !important;
			float: right;
			display: inline-block !important;
		}
		#sideBarList{
			display: inline-block;
			float: left;
			width: 25vw;
			height: ;
			background: #f9f9f9;
			box-shadow: 1px 1px 20px #3c3c3c;
			margin: 1vw;
			border-radius: 5px;
			padding: 5px 10px;
			overflow: auto; 
		}
		#listToHire{
			list-style: none;
			margin: 0;
			padding: 0;
			max-height: calc(100vh - 350px);
		}
		#listToHire li{
			padding: 2px 0;
			margin: 3px 0;
			border: 1px solid grey; 
			float: left;
			width: 100%;
			border-left: none;
			border-right: none;
			display: block;

		}
	</style>

	<script type="text/javascript" defer="true">
		$(document).ready( function(){
			var table = $('#doctorTbl').DataTable( {
			        rowReorder: {
			            selector: 'td:nth-child(2)'
			        },
			        responsive: true
			    } );

			if($(window).width()> 720){
					$('#sideBarList').addClass('min');
				}else{
					$('#sideBarList').removeClass('min');
				}



			$('#filterByService').change( function(){
				var filter = $(this).val();
				console.log(filter);
				var url = 'sgetFilteredData.php';
				var data = {filterKey: filter};
				$.post(url, data, function(res){
					console.log(res);
					table.destroy();
					var $appentTo = $('#doctorTbl tbody');
					 $appentTo.html('');
					 var loop = res.id.length;
					 var i;
					 for(i=0; i<loop; i++){
					 	$appentTo.append('<tr id="'+res.id[i]+'" class="docRecords odd" role="row"><td height="80px" style="max-height: 100px" tabindex="0" class="sorting_1"><img src="'+ res.image[i] +'" width="80vw"></td><td width="30%">'+ res.name[i]+'</td><td style="">'+res.sex[i]+'</td><td style="">'+res.service[i]+'</td><td style="">'+res.address+' </td><td style="">'+res.wRate[i]+'</td><td style="">'+res.feedbackrate[i]+'</td><td style=""><a href="#" id="'+res.id[i]+'" class="btn btn-primary btnAddPersonToHire">Add to Hiring List</a></td></tr>');
					 }
 				table = $('#doctorTbl').DataTable( {
			        rowReorder: {
			            selector: 'td:nth-child(2)'
			        },
			        responsive: true
			    } );

				}, 'json')
				.fail( function(){
					alert('An error has occured while Loading list.')
				})
			});


			$(document).on('click', '.btnAddPersonToHire', function(){
				var id = $(this).attr('id');

				if($('#sideBarList').hasClass('active') == false){
					$('#tblDivCon').addClass('withSideListActive');
					$('#sideBarList').css('display', 'inline-block').addClass('active');
					if($(window).width()<720){
						$('#tblDivCon').css('height', 'calc(100vh - 210px)');
						$('#tblDivCon').css('overflow', 'auto');
					}
				}
				var $this = $('#doctorTbl #'+id+'');
				$(this).prop('disabled', true);

				$('#listToHire').append('<li id="'+$this.attr('id')+'"><div style="display: inline-block; float: left"><img src="'+$this.find('img').attr('src')+'" height="50px" ></div><div style="display: inline-block; float: left; padding: 5px 0 0 0"><h4 style="display: block; margin: 0">'+ $this.find("td:nth-child(2)").html() +'</h4><span>'+$this.find("td:nth-child(4)").html()+'</span></div><div style="display: inline-block; float: right;padding: 5px 0 0 0"><button type="button" class="btn btn-danger btnRemoveFromHireList"><span class="glyphicon glyphicon-remove"></span></button></div></li>');

				changeToHireCounter('inc');
			});

			$(document).on('click', '.btnRemoveFromHireList', function(){
				$(this).parent().parent().fadeOut();
				var id = $(this).parent().parent().attr('id');
				console.log(id);
				$('#tblDivCon a#'+id+' ').prop('disabled', false);
				changeToHireCounter('dec');

				if(Number($('#toHireCount').html()) == 0){
					$('#sideBarList').fadeOut().removeClass('active');
					$('#tblDivCon').removeClass('withSideListActive');
					if($(window).width()<720){
						$('#tblDivCon').css('height', '100vh');
						$('#tblDivCon').css('overflow', 'auto');
					}
				}
			})

			$(window).on('resize', function(){
				if($(window).width()> 720){
					$('#sideBarList').addClass('min');
				}else{
					$('#sideBarList').removeClass('min');
				}
			})


			function changeToHireCounter(ope){
				if(ope == 'inc'){
					$('#toHireCount').html(Number($('#toHireCount').html()) + 1)
				}else if( ope == 'dec'){
					$('#toHireCount').html(Number($('#toHireCount').html()) - 1)
				}
			}
		    	
		});
			

	</script>

</head>
<body id="homepageBody">

	<header id="homepageHeader" style="height: 180px; display: block; width: 100%; background: grey">
		<img src="img/logo b.png" style="height: 100%;">
	</header>
	
	<main>
		<header class="navbar navbar-static-top bs-docs-nav" id="top" role="banner" style="margin: 0; background:#000000; height: 40px">
		  <div class="container">
		    <div class="navbar-header" style="height: 100%">
		      <button class="navbar-toggle collapsed" type="button" data-toggle="collapse" data-target="#bs-navbar" aria-controls="bs-navbar" aria-expanded="false"  style="color: white; font-size: 25px; margin: 0">
		        <span class="glyphicon glyphicon-menu-hamburger"></span>
		        
		      </button>
		    
		    </div>
		    <nav id="bs-navbar" class="collapse navbar-collapse" style="background: black;">
		      <ul class="nav navbar-nav">
		        <li>
		          <a href="#">Home</a>
		        </li>
		        <li>
		          <a href="mycontracts.php">My contracts</a>
		        </li>
		      </ul>
		      
		    </nav>
		  </div>
		</header>
		<div id="sideBarList" class="" style="display: none;">
			<h4 style="display: inline-block;">List of people to hire</h4>
			<span class="badge" id="toHireCount" style="display: inline-block; float: right; margin:8px 0 0 0; font-size: 15px">0</span>
			<hr style="margin: 10px 0">
			<ul id="listToHire">
				
			</ul>
			<div style="display: block; width: 100%">
				<button type="button" id="btnSendService" class="btn btn-warning" style="width: 100%">
					Send service request
				</button>
			</div>
		</div>
		
		<div id="tblDivCon" class="">
			<div class="form-group">
				<label style="display: block; text-align: left;">Filter by Service:</label>
				<select class="form-control" id="filterByService">
					<option value="0">No Filter</option>
					<?php
						$query = "SELECT * FROM category_services";
						$exeQuery = mysqli_query($con, $query);
						while($get = mysqli_fetch_array($exeQuery)):
					?>
						<option value="<?php echo $get['id']?>"><?php echo $get['service_name']?></option>
					<?php endwhile; ?>
				</select>
			</div>
			<table id="doctorTbl" class="display nowrap" style="width:100%">
		        <thead>
		            <tr>
		            	<th width="80px">Photo</th>
		                <th >Name</th>
		                <th>Sex</th>
		                <th>Service</th>
		                <th>Address</th>
		                <th>Work Rate</th>
		                <th>Rating and Feedback</th>
		                <th>Action</th>
		            </tr>
		        </thead>
		        <tbody>
		        	<?php
		        		require 'dbConfig.php'; 
		        		$query = "SELECT * FROM s_provider INNER JOIN customer ON  s_provider.userid = customer.id INNER JOIN category_services ON s_provider.service = category_services.id";
		        		$exeQuery = mysqli_query($con, $query);
		        		//echo('<script>alert('. mysqli_num_rows($exeQuery). ')</script>');
		        		while($get = mysqli_fetch_array($exeQuery)):

		        	?>

		        		<tr class="docRecords odd" id="<?php echo($get['userid'])?>" role="row" >
		        			<td height="80px" style="max-height: 100px" tabindex="0" class="sorting_1">
		        				<img src="<?php echo($get['user_image'])?>" width="80vw">
		        			</td>
		        			<td width="30%"><?php echo($get['f_name'] . ' ' . $get['m_name'] . '. ' . $get['l_name'] )?></td>
		        			<td style=""><?php echo($get['sex'])?></td>
		        			<td style=""><?php echo($get['service_name'])?></td>
		        			<td style=""><?php echo($get['user_address'])?> </td> 
		        			<td style=""><?php echo($get['work_rate'])?></td>
		        			<td style=""><?php echo($get['gen_rate'])?></td>
		        			<td style="">
		        				<a href="#" id="<?php echo($get['userid'])?>" class="btn btn-primary btnAddPersonToHire">Add to Hiring List</button>
		        			</td>
		        		</tr>

		        	<?php
		        		endwhile;
		        	?>

		        </tbody>
		    </table>
		</div>

	</main>

<div class="customModal" id="lastStepSubmitJR">
	<div class="customModal-body">
		<div class="customModal-title">
			<h5><!-- title here -->Job Schedule</h5>
			<button type="button" class="btn modalClose">
				<i class="glyphicon glyphicon-remove"></i>
			</button>
		</div>
		<div class="customModal-content">
			<form id="frmFileJobRequestWithDate" method="POST">
				<label>When is the job starting?</label>
				<input type="date" name="dateStart" class="form-control" required>
				<br>
				<label>When will the job end?</label>
				<input type="date" name="dateEnd" class="form-control" required>
				<hr>
				<button type="submit" class="btn btn-primary">
					Submit Job Request
				</button>
			</form>
		</div>
		</div>
	</div>
</div>


	<script type="text/javascript" defer="true">
		$(document).ready( function(){

			$('#frmFileJobRequestWithDate').submit( function(event){
				event.preventDefault();
				var data = $(this).serializeArray();

				//get data from child of ul#listToHire
				var loop = $('#listToHire li').length;
				var i;
				var userid = [];
				var service = [];
				var $list = $('#listToHire');
				var customerId = 3;
				for(i=1; i<=loop; i++){
					var $li = $list.find('li:nth-child('+i+')');
					userid.push($li.attr('id'));
					service.push($.trim($li.find('span').html().toString()));
					console.log($li.find('span').html().toString());
				}
					data.push({name:'userId', value:userid});
					data.push({name:'service', value:service});
					data.push({name:'customerId', value:customerId});
				
				var url = 'fileJobRequest.php';
				$.post(url, data, function(res){
					if(res.status == true){
						alert('Job request has been filed successfully. Please wait for the notification if the requested service provider accepts the job request');

						$('.customModal').customModal('hide')
						$('a').prop('disabled', false);
						$('#listToHire').html('');
						$('#sideBarList').fadeOut().removeClass('active');
						$('#tblDivCon').removeClass('withSideListActive');
						$('#toHireCount').html(0);
					}else{
						alert('Could not submit job request at the moment');
					}

				}, 'json')
				.fail( function(){
					alert('An error occured while filing a job request');
				})
			})

			$('.modalClose').click( function(){
				$('.customModal').customModal('hide');
			})

			$('#btnSendService').click( function(){

				$('#lastStepSubmitJR').customModal();

				/*//*/
			});

		});//end of docu ready
	</script>

</body>
</html>