<?php
include "dbConfig.php";
session_start();

$sid = $_GET['sid'];
mysqli_query($con,"Delete from category_services where id = $sid");
header("Location:addservices.php");
?>