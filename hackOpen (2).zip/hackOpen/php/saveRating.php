<?php
	session_start();
	require 'dbConfig.php';

	$rate = $_POST['myrate'];
	$proToRate = $_POST['serProId'];
	$service = $_POST['serviceProvided'];
	$userId = $_SESSION['userId'];
	$status = false;

	$query = "INSERT INTO ratings( service_provider, customer, service, rate) VALUES('$proToRate', '$userId', '$service', '$rate')";
	$exeQuery = mysqli_query($con, $query);
	if($exeQuery){
		$status = true;
	}

	echo json_encode(
		array(
			'status' => $status
		)
	);

	mysqli_close($con);