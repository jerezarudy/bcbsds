<?php
	require 'dbConfig.php';

	$userId = $_POST['userId'];
	$verCode = $_POST['verificationCode'];

	$status = false;

	$query = "SELECT * FROM verficationcode WHERE customer_id ='$userId' AND code ='$verCode'";
	$exeQuery = mysqli_query($con, $query);
	if(mysqli_num_rows($exeQuery) > 0){
		$get = mysqli_fetch_array($exeQuery);

		$status = true;

		//set session for user id
		$_SESSION['userId'] = $userId;
		setcookie('userId', $userId, time() + (86400 * 30), "/");

		//delete verification code in db
		$codeId = $get['id'];
		$query = "DELETE FROM verficationcode WHERE id='$codeId'";
		$exeQuery = mysqli_query($con, $query);

	}

	echo json_encode(
		array(
			'status' => $status
		)
	);

	mysqli_close($con);