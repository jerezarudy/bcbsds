<html>
<?php
include "dbConfig.php";
session_start();
$id = $_SESSION['session_id'];
$tid = $_GET['tid'];
if($_SESSION['session_id']==true){
?>
<head>
<title>BCBSDS</title>
<script src="js/jquery.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/dataTables.min.js" defer="true"></script>
<script src="js/dataTables.responsive.min.js" defer="true"></script>
<script src="js/dataTables.rowReorder.min.js" defer="true"></script>

<link rel="stylesheet" href="css/bootstrap.css"/>
<link rel="stylesheet" href="css/akun.css"/>
<link rel="stylesheet" href="css/dataTables.min.css"/>
<link rel="stylesheet" href="css/responsive.dataTables.min.css"/>
<link rel="stylesheet" href="css/rowReorder.dataTables.min.css"/>

</head>


<body>
	<div class="side">
		<img src="img/logo b.png"/>
		
		<div class="sidenavv">
		<hr style="    margin-bottom: 37px;">
			<ul class="pililian">
				<a href="admin.php" style="text-decoration: none;"><li class=""><i class="glyphicon glyphicon-home"></i> Home</li></a>
				<a href="listresidence.php" style="text-decoration: none;"><li><i class="glyphicon glyphicon-list"></i> List of Residents</li></a>
				<a href="listserviceprovider.php" style="text-decoration: none;"><li><i class="glyphicon glyphicon-list"></i> List of Service Providers</li></a>
				<a href="addservices.php" style="text-decoration: none;"><li class=""><i class="glyphicon glyphicon-plus"></i> Add Services</li></a>
				<a href="activehiring.php" style="text-decoration: none;"><li class="activee"><i class="glyphicon glyphicon-book"></i> View Active Hirings</li></a>
				
			</ul>
			<a href="logout.php" style="text-decoration: none;color: #fff; "><div class="loooog"><i class="glyphicon glyphicon-log-out"></i> Logout
			</div></a>
		</div>
	</div>
	<div class="headdd">
		
		
	</div>
	<div class="lawas">
		<div class="titlee">
		Print Hirings
		</div>
		<div class="contentt" id="contentt">
				<center> <h2>Contract Agreement</h2> </center>
			<div class="col-md-12">
			<?php
			$result = mysqli_query($con,"SELECT * FROM hiring_log as A INNER JOIN customer as B on A.customer = B.id INNER JOIN s_provider as C on A.service_provider = C.id INNER JOIN category_services as D on A.service_id = D.id where trans_id = $tid");
			$data = mysqli_fetch_object($result);
			$re = $data->service_provider;
			$result1 = mysqli_query($con, "Select * from customer where id = $re");
			$data1 = mysqli_fetch_object($result1);
			?>
			<hr>
			<h4>Contractor:</h4><br>
				<img src="<?php echo $data->user_image; ?>"  class="img-circle" alt="User Image" style="width:200px; ">
				<div style="    width: 400px;
				position: absolute;
				margin-left: 210px;
				margin-top: -144px;">
				Name: <?php echo $data->l_name; ?>, <?php echo $data->f_name; ?> <?php echo $data->m_name; ?><br>
				Cellphone Number: <?php echo $data->phone_number; ?><br>
				
				Address: <?php echo $data->user_address; ?><br>
				
				</div>
				<hr style="">
				<h4 style="">Service Provider:</h4><br>
				<img src="<?php echo $data1->user_image; ?>"  class="img-circle" alt="User Image" style="width:200px;float:left;">
				<div style="    width: 400px;
				position: absolute;
				margin-left: 210px;margin-top:60px;">
				Name: <?php echo $data1->l_name; ?>, <?php echo $data1->f_name; ?> <?php echo $data1->m_name; ?><br>
				Cellphone Number: <?php echo $data1->phone_number; ?><br>
				
				Address: <?php echo $data1->user_address; ?><br>
				
				</div>
				
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<hr>
				<div style="    float: left;text-align: justify;">
				 <br><br>

				&emsp;This letter serves as a formal agreement between <u><?php echo $data->l_name; ?>, <?php echo $data->f_name; ?></u> and <u><?php echo $data1->l_name; ?>, <?php echo $data1->f_name; ?></u>, whereby <u><?php echo $data1->l_name; ?>, <?php echo $data1->f_name; ?></u> will provide professional services of <u><?php echo $data->service_desc; ?></u>, on <u><?php echo $data->date_accepted; ?></u> to <u><?php echo $data->date_ended; ?></u>, at the following location: 

				Address: <u><?php echo $data->user_address; ?></u>
				<br>
				&emsp;<u><?php echo $data->l_name; ?>, <?php echo $data->f_name; ?></u> obliged to pay <u><?php echo $data1->l_name; ?>, <?php echo $data1->f_name; ?></u> for services provided in the amount of Php <u><?php echo $data->work_rate; ?> per Day</u>. Payment will be disbursed upon completion of all services. Please sign the copy of this agreement. 

				Best regards, 
				<br>
				<br>
				<br>
				________________________________ &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;________________________________<br>
				&emsp;&emsp;&emsp;Contractor's Signature&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Service provider's Signature	

				</div>
			</div>
			
		</div>
		<a style="float:right;margin-right:20px;" class="btn btn-success" href="" onClick="printPageArea1()">Print</a>	
	</div>


</body>
<script>
		function printPageArea1(){
		var printContent = document.getElementById("contentt");
		var WinPrint = window.open('', '', 'width=900,height=650');
		WinPrint.document.write(printContent.innerHTML);
		WinPrint.document.close();
		WinPrint.focus();
		WinPrint.print();
		WinPrint.close();
		};
</script>
<?php
}
else{
header('Location:index.php');
}
?>
</html>