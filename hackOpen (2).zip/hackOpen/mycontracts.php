<?php
	session_start() ;
	include "dbConfig.php";

?>
<!DOCTYPE html>
<html>
<head>

	<title>BCBSDS</title>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/mymain.js"></script>
	<script type="text/javascript" src="js/dataTables.min.js"></script>
	<script type="text/javascript" src="js/dataTables.responsive.min.js"></script>
	<script type="text/javascript" src="js/dataTables.rowReorder.min.js"></script>

	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/animate.css">
	<link rel="stylesheet" type="text/css" href="css/custom.css">
	<link rel="stylesheet" type="text/css" href="css/media.css">
	<link rel="stylesheet" type="text/css" href="css/dataTables.min.css">
	<link rel="stylesheet" type="text/css" href="css/responsive.dataTables.min.css">
	<link rel="stylesheet" type="text/css" href="css/rowReorder.dataTables.min.css">


	<style type="text/css">
		#btnMenu{
			background:none;
			border: none;
			color: white;
			font-size: 20px

		}
		#submenu{
			height: calc(100vh - 40px);
			width: 80vw;
			position:absolute;
			background: #333;
			bottom: 0;
			display: none;
			z-index: 1;
		}
		.divCon{
			display: none;
			width: 100%;
			padding:10px;
		}
		.divCon.active{
			display: block !important;
		}
		#docRateReview{
			list-style: none;
			padding:0;
			margin: 0;
			overflow: auto;
			height: 150px;
			margin: 10px 0;
		    border: 1px solid grey;
		    padding: 5px;
		}
		#docRateReview li{
			padding: 0;
			margin:0 ;
			display: inline-block;
		}
		#tblDivCon{
			display: block; 
			margin: 10px auto; 
			padding: 2vw; 
			width: 95%;
			border-radius: 10px;
			background: #f9f9f9;
			box-shadow: 1px 1px 20px #3c3c3c;
		}
		.withSideListActive{
			width: 70vw !important;
			float: right;
			display: inline-block !important;
		}
		#sideBarList{
			display: inline-block;
			float: left;
			width: 25vw;
			height: ;
			background: #f9f9f9;
			box-shadow: 1px 1px 20px #3c3c3c;
			margin: 1vw;
			border-radius: 5px;
			padding: 5px 10px;
			overflow: auto; 
		}
		#listToHire{
			list-style: none;
			margin: 0;
			padding: 0;
			max-height: calc(100vh - 350px);
		}
		#listToHire li{
			padding: 2px 0;
			margin: 3px 0;
			border: 1px solid grey; 
			float: left;
			width: 100%;
			border-left: none;
			border-right: none;
			display: block;

		}
	</style>

	<script type="text/javascript" defer="true">
		$(document).ready( function(){
			var table = $('#doctorTbl').DataTable( {
			        rowReorder: {
			            selector: 'td:nth-child(3)'
			        },
			        responsive: true
			    } );

			if($(window).width()> 720){
					$('#sideBarList').addClass('min');
				}else{
					$('#sideBarList').removeClass('min');
				}



			$('#filterByService').change( function(){
				var filter = $(this).val();
				console.log(filter);
				var url = 'getFilteredData.php';
				var data = {filterKey: filter};
				$.post(url, data, function(res){
					console.log(res);
					table.destroy();
					var $appentTo = $('#doctorTbl tbody');
					 $appentTo.html('');
					 var loop = res.id.length;
					 var i;
					 for(i=0; i<loop; i++){
					 	$appentTo.append('<tr id="'+res.id[i]+'" class="docRecords odd" role="row"><td height="80px" style="max-height: 100px" tabindex="0" class="sorting_1"><img src="'+ res.image[i] +'" width="80vw"></td><td width="30%">'+ res.name[i]+'</td><td style="">'+res.sex[i]+'</td><td style="">'+res.service[i]+'</td><td style="">'+res.address+' </td><td style="">'+res.wRate[i]+'</td><td style="">'+res.feedbackrate[i]+'</td><td style=""><a href="#" id="'+res.id[i]+'" class="btn btn-primary btnAddPersonToHire">Add to Hiring List</a></td></tr>');
					 }
 				table = $('#doctorTbl').DataTable( {
			        rowReorder: {
			            selector: 'td:nth-child(2)'
			        },
			        responsive: true
			    } );

				}, 'json')
				.fail( function(){
					alert('An error has occured while Loading list.')
				})
			});


			$(document).on('click', '.btnAddPersonToHire', function(){
				var id = $(this).attr('id');

				if($('#sideBarList').hasClass('active') == false){
					$('#tblDivCon').addClass('withSideListActive');
					$('#sideBarList').css('display', 'inline-block').addClass('active');
					if($(window).width()<720){
						$('#tblDivCon').css('height', 'calc(100vh - 210px)');
						$('#tblDivCon').css('overflow', 'auto');
					}
				}
				var $this = $('#doctorTbl #'+id+'');
				$(this).prop('disabled', true);

				$('#listToHire').append('<li id="'+$this.attr('id')+'"><div style="display: inline-block; float: left"><img src="'+$this.find('img').attr('src')+'" height="50px" ></div><div style="display: inline-block; float: left; padding: 5px 0 0 0"><h4 style="display: block; margin: 0">'+ $this.find("td:nth-child(2)").html() +'</h4><span>'+$this.find("td:nth-child(4)").html()+'</span></div><div style="display: inline-block; float: right;padding: 5px 0 0 0"><button type="button" class="btn btn-danger btnRemoveFromHireList"><span class="glyphicon glyphicon-remove"></span></button></div></li>');

				changeToHireCounter('inc');
			});

			$(document).on('click', '.btnRemoveFromHireList', function(){
				$(this).parent().parent().fadeOut();
				var id = $(this).parent().parent().attr('id');
				console.log(id);
				$('#tblDivCon a#'+id+' ').prop('disabled', false);
				changeToHireCounter('dec');

				if(Number($('#toHireCount').html()) == 0){
					$('#sideBarList').fadeOut().removeClass('active');
					$('#tblDivCon').removeClass('withSideListActive');
					if($(window).width()<720){
						$('#tblDivCon').css('height', '100vh');
						$('#tblDivCon').css('overflow', 'auto');
					}
				}
			})

			$(window).on('resize', function(){
				if($(window).width()> 720){
					$('#sideBarList').addClass('min');
				}else{
					$('#sideBarList').removeClass('min');
				}
			})


			function changeToHireCounter(ope){
				if(ope == 'inc'){
					$('#toHireCount').html(Number($('#toHireCount').html()) + 1)
				}else if( ope == 'dec'){
					$('#toHireCount').html(Number($('#toHireCount').html()) - 1)
				}
			}
		    	
		});
			

	</script>

</head>
<body id="homepageBody">

	<header id="homepageHeader" style="height: 180px; display: block; width: 100%; background: grey">
		<img src="img/logo b.png" style="height: 100%;">
	</header>
	
	<main>
		<header class="navbar navbar-static-top bs-docs-nav" id="top" role="banner" style="margin: 0; background:#000000; height: 40px; z-index: 2">
		  <div class="container">
		    <div class="navbar-header" style="height: 100%">
		      <button class="navbar-toggle collapsed" type="button" data-toggle="collapse" data-target="#bs-navbar" aria-controls="bs-navbar" aria-expanded="false"  style="color: white; font-size: 25px; margin: 0">
		        <span class="glyphicon glyphicon-menu-hamburger"></span>
		        
		      </button>
		    
		    </div>
		    <nav id="bs-navbar" class="collapse navbar-collapse" style="background: black;">
		      <ul class="nav navbar-nav">
		        <li>
		          <a href="homepage.php">Home</a>
		        </li>
		        <li>
		          <a href="#">My contracts</a>
		        </li>
		      </ul>
		      
		    </nav>
		  </div>
		</header>
		<div id="sideBarList" class="" style="display: none;">
			<h4 style="display: inline-block;">List of people to hire</h4>
			<span class="badge" id="toHireCount" style="display: inline-block; float: right; margin:8px 0 0 0; font-size: 15px">0</span>
			<hr style="margin: 10px 0">
			<ul id="listToHire">
				
			</ul>
			<div style="display: block; width: 100%">
				<button type="button" id="btnSendService" class="btn btn-warning" style="width: 100%">
					Send service request
				</button>
			</div>
		</div>
		
		<div id="tblDivCon" class="">
			
			<table id="doctorTbl" class="display nowrap" style="width:100%">
		        <thead>
		            <tr>
		            	<th>Contract ID</th>
		                <th>Service Provider</th>
		                <th>Service Provided</th>
		                <th>Date of service</th>
		                <th>My Rating</th>
		                <th>Action</th>
		            </tr>
		        </thead>
		        <tbody>
		        	<?php		        		

		        		//$userId = $_SESSION['userId'];
		        		//$userId =  $_SESSION['userId'];

		        		$query = "SELECT * FROM hiring_log INNER JOIN customer ON  hiring_log.customer = customer.id INNER JOIN category_services ON hiring_log.service_id = category_services.id INNER JOIN s_provider ON s_provider.userid = hiring_log.service_provider WHERE hiring_log.customer = '3'";
		        		$exeQuery = mysqli_query($con, $query);
		        		
		        		while($get = mysqli_fetch_array($exeQuery)):
		        			$asd = $get['service_provider'];

		        			$query2 = "SELECT * FROM customer WHERE id = '$asd'";
		        			$eQ2 = mysqli_query($con, $query2);
		        			$get2 = mysqli_fetch_array($eQ2);

		        	?>

		        		<tr class="docRecords odd" id="<?php echo($get['userid'])?>" role="row" >
		        			<td style=""><?php echo($get['trans_id'])?></td>
		        			<td width="30%"><?php echo($get2['f_name'] . ' ' . $get2['m_name'] . '. ' . $get2['l_name'] )?></td>
		        			<td style=""><?php echo($get['service_name'])?></td>
		        			<td style=""><?php echo($get['date_accepted'])?></td>
		        			<td style=""><?php echo($get['gen_rate'])?> </td> 
		        			<td>
		        				<button type="button" id="<?php echo($get['trans_id'])?>" class="btn btn-primary btnAddRate">
		        					Add rating
		        				</button>
		        			</td>
		        		</tr>

		        	<?php
		        		endwhile;
		        	?>

		        </tbody>
		    </table>
		</div>

	</main>

<div class="customModal" id="modalAddRate">
	<div class="customModal-body">
		<div class="customModal-title">
			<h5><!-- title here -->Leave rating</h5>
			<button type="button" class="btn modalClose">
				<i class="glyphicon glyphicon-remove"></i>
			</button>
		</div>
		<div class="customModal-content">
			<form id="frmSaveRating" method="POST">
				<label>Enter your rate: (1-5)</label>
				<input type="Number" name="myrate" max="5" min="1" class="form-control" required style="text-align: center" placeholder="Enter your rate here">
				<input type="text" name="serProId" value="" hidden>
				<input type="text" name="serviceProvided" value="" hidden>
				<br>
				<button type="submit" class="btn btn-primary">
					Submit Rating
				</button>
			</form>
		</div>
		</div>
	</div>
</div>


	<script type="text/javascript" defer="true">
		$(document).ready( function(){
			$('.modalClose').click( function(){
				$('.customModal').customModal('hide');
			})

			$('#frmSaveRating').submit( function(event){
				event.preventDefault();

				var data = $(this).serialize();
				var url = "saveRating.php";
				$.post(url, data, function(res){
					if(res.status == true){
						alert('Your have successfully rated this service provider.');
						$('.customModal').customModal('hide');

					}else{
						alert('An error occured while saving rating.');
					}

				}, 'json')
				.fail( function(){

				})

			});


			$(document).on('click', '.btnAddRate', function(){
				var id = $(this).attr('id');
				var service = $('tr#' + id + ' ').html();
				$('#modalAddRate').customModal();
				$('input[name=serProId]').val(id);
				$('input[name=serviceProvided]').val(service);
			});

		})
	</script>


</body>
</html>