

//start custom functions
$.fn.customModal = function(action) {
     	if (action === 'show') {
     		$(this).slideDown('500');
     	}else if(action === null){
     		$(this).slideDown('500');
     	}else if(action === 'hide'){
     		$(this).slideUp('500');
     	}
      return this;
   	}; 


//generate user id
//this will be used in the sign up page
function getUserId(){
	//user id will be consist of date(month and day) he was registered with 3 random numbers(ranging from 0-100)
	//ex 364542

	//getting date
	var a = new Date;
	var b = a.getUTCMonth() + 1;
		b = b.toString();
	
	var a = new Date;
	var c = a.getUTCDate();
		c = c.toString();

	var rnumber = '';
	//get random number from range 1-100
	for( var i = 0; i<3; i++){
		var d = Math.floor((Math.random() * 100) + 1);
			d = d.toString();
			//console.log(d);

		rnumber = rnumber + d;
		//console.log(rnumber);
	}


	//putting all together
	var userId= b + c + rnumber; //this is the user id
	//console.log(userId);

	//we need to check if the generated user id is already existing in the db
	//processing will take place in a external php file
	var url = 'checkUserId.php';
	$.post( url, { data: userId}, function(response){

		if (response.rowCount == 0) {
			//generated user id is ok for use
		}else{
			//user id is duplicated
			getUserId();
		}

	}, "json");


//returning user id
return userId;
}







//end custom functions

