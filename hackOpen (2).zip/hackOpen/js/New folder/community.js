//jQuery for community page and sub pages
		$(document).ready( function(){

			//tabs icons and contents on aside element
			$("#iconForum").click( function(){
				//setting icon active
				$("#tabIcons ul center li a").removeClass('activeIcon');
				$("#iconForum").addClass('activeIcon');

				//changing contents
				$("#pageMain ul li").removeClass('active');
				$("#contentForum").addClass('active');
			});//end of iconForum click

			$("#iconProfile").click( function(){
				//setting icon active
				$("#tabIcons ul center li a").removeClass('activeIcon');
				$("#iconProfile").addClass('activeIcon');

				//changing contents
				$("#pageMain ul li").removeClass('active');
				$("#contentProfile").addClass('active');
			});//end of iconForum click

			$("#iconChat").click( function(){
				//setting icon active
				$("#tabIcons ul center li a").removeClass('activeIcon');
				$("#iconChat").addClass('activeIcon');

				//changing contents
				$("#pageMain ul li").removeClass('active');
				$("#contentChat").addClass('active');
			});//end of iconForum click


			//js on profile page
			$("#profileInfoTab").click( function(){
				//switch active tab
				$("#profileInfo li a").removeClass('active');
				$("#profileInfoTab").addClass('active');
				//switch active contents
				$("#profileTabContent li").removeClass('active');
				$("#profileMyInfoContent").addClass('active');
			});
			$("#buddyListTab").click( function(){
				//switch active tab
				$("#profileInfo li a").removeClass('active');
				$("#buddyListTab").addClass('active');
				//switch active contents
				$("#profileTabContent li").removeClass('active');
				$("#profileBuddyContent").addClass('active');
			});

		
		
		$(".dropMenuBud").click( function(){
			$(this).siblings('#dropdownBuddyMenu').slideToggle();
		});

		//modal for confirmation of message delete
		$(".deleteThisMessage").click( function(){
			$("$deleteMessage").customModal();
		});	

		//tabs for messages(switching between single and group)
		$("#singleMessageTab").click( function(){
			$('#messageTabs li').removeClass('activeMessageTab');
			$(this).parent().addClass('activeMessageTab');
			$("#singleMessages").addClass('activeMessage');
			$("#groupMessages").removeClass('activeMessage')
		});
		$("#groupMessageTab").click( function(){
			$('#messageTabs li').removeClass('activeMessageTab');
			$(this).parent().addClass('activeMessageTab');
			$("#singleMessages").removeClass('activeMessage');
			$("#groupMessages").addClass('activeMessage');
		});




		// posting new forum thread
		$('#newForumPostForm').submit( function(e){
			e.preventDefault();
			
			//get date in month date, year format ex: january 1, 2018
				//get year
				var d = new Date();
				var year = d.getUTCFullYear();
				//get day of the month
				var d = new Date();
		    	var day = d.getUTCDate()+1;
		 		//get month
		 		var d = new Date();
			    var month = new Array(12);
			    month[0] = "January";
			    month[1] = "February";
			    month[2] = "March";
			    month[3] = "April";
			    month[4] = "May";
			    month[5] = "June";
			    month[6] = "July";
			    month[7] = "August";
			    month[8] = "September";
			    month[9] = "October";
			    month[10] = "November";
			    month[11] = "December";

			    var month = month[d.getUTCMonth()];

			    //concatinate date
			    var mydate = month + " " + day + ", " + year;

				//get time
				var time = new Date();
				
				var cTime= time.toLocaleString('en-US', { hour: 'numeric', minute: 'numeric', hour12: true });


			//this contains the user id
			var id = getCookie('userId');
			
			var data = $(this).serializeArray();
				data.push({name: 'datePost', value: mydate});
				data.push({name: 'timePost', value: cTime});
				data.push({name: 'userId', value: id});
			var url = 'ajax/saveNewForum.php';

			$.post( url, data, function(response){

				window.location.href= 'myThreads.html';

			}, "json");

		});

		


		////////////////////////////////////////////////
		//image as radio buttons
		$(".radioImg img").click( function(){
			//removing classsess and checked status
			$(this).parent().parent().find('label').removeClass('imgMoodActive');
			$(this).parent().parent().find('input').attr('checked', false);
			$(this).parent().removeClass('imgMoodActive');

			//setting class and chedked status
			$(this).prev().attr('checked',true);
			$(this).parent().addClass('imgMoodActive');
		});



		////////////////////////////////////////////
		//submit choosen image as radio
		$("#avatarForm").submit( function(noLoad){
			noLoad.preventDefault();

			var src = $(this).find('input:checked').next().attr('src');
			$("#viewAvatar img").css('display', 'block');
			$("#viewAvatar img").attr('src', src);
			//closing modal
			$('#chooseAvatar').slideUp();
		});


		
		//////////////////////////////////////////////
		//threadList showing/hiding of thread info
		var iconswitch = 0;
		$("#myOldThreads").on('click', '.threadRowLink',  function(){
			
			$(this).find('.triangleIcon').toggleClass('glyphicon-triangle-right glyphicon-triangle-bottom');

			$(this).siblings('.threadInfo').slideToggle();
	
		});


		////////////////////////////
		//forum delete my thread modal open
		//var threadId = 0;
		$("#myOldThreads").on('click', '.deleteThread', function(){
			//threadId = $(this).parent().parent().attr('id');
			//console.log(threadId);
			var id = $(this).attr('id');
			console.log("thread id:" + id);
			var url = 'ajax/deleteMythread.php'
			$.post(url, {data:id}, function(response){

				var status = response.status;
				if(status == true){
					//delete thread display
					$("li#"+id+"").fadeOut();
				}

			},"json");
		});


		//////////////////////////////////
		//view the selected forum thread from my threads
		$("#myOldThreads").on('click', '.viewThread', function(){
			var id = $(this).attr('id');

			//set id to cookie
			document.cookie = "threadId="+id+";path=/";
			//redirect to another view thread page
			window.location.href="viewMyThread.html";
		});


		//////////////////////////////////////
		//opening closing of reply box
		$('#replyBoxToggle').click( function(){
			$("#replyBox").slideToggle();
			$(this).find('i').toggleClass('glyphicon-triangle-right glyphicon-triangle-bottom');
		});


		//////////////////////////////////////
		//threads opening and closing of thread info
		//on recent and browse thread post
		
		$(".recentThreadRow").on('click', '.btnShowThreadInfo', function(){
			
			$(this).children('i').toggleClass('glyphicon-triangle-right  glyphicon-triangle-bottom');
			$(this).parent().siblings('.threadInfo ').slideToggle();

		});


		/////////////////////////////////////
		//redirecting from recent and browse thread page 
		//to view thread page
		$(".recentThreadRow").on('click', '.viewThread', function(){

			var passIdtoView = $(this).attr('id');

			document.cookie = "threadId="+passIdtoView+";path=/";
			window.location.href="viewMyThread.html";

		});
		$("#genTalks").on('click', '.viewThread', function(){

			var passIdtoView = $(this).attr('id');

			document.cookie = "threadId="+passIdtoView+";path=/";
			window.location.href="viewMyThread.html";

		});
		


/////////
//functions




//end of jquery for community page and subpages
//----------------------------------------------------------------
});//end of document ready
 function getAllMessages(type){
 	$("#singleMessages").html("");
 	var url = 'messages/loadMessages.php';

 		$.post(url, {data:type}, function(response){
	 		console.log(response);
	 		
	 		for( var i = 0; i <response.numRows; i++){
	 			$("#singleMessages").append('<li class="messageLi"><a href="messageThread.html" class="messageLink"><div class="messageDivMain"><img src="../img/avatar1.png" class="messageAvatar"><p class="messageAvatarName">'
	 				+ response.id[i] +
	 			'</p><p class="messageExcerpt">Lorem Ipsum Sit Amet</p></div></a><button class="btn btn-default dropMessageMenu dropMenuBud"><i class="glyphicon glyphicon-option-vertical"></i></button><ul id="dropdownBuddyMenu" class="messageDropMenuOption"><li><a href="#" class="deleteThisMessage">Delete Thread</a></li></ul></li>');
	 		}

	 	},"json");
 }



 //////////////////////////////////////
 function getCookie(cname) {
	    var name = cname + "=";
	    var decodedCookie = decodeURIComponent(document.cookie);
	    var ca = decodedCookie.split(';');
	    for(var i = 0; i <ca.length; i++) {
	        var c = ca[i];
	        while (c.charAt(0) == ' ') {
	            c = c.substring(1);
	        }
	        if (c.indexOf(name) == 0) {
	            return c.substring(name.length, c.length);
	        }
	    }
	    return "";
	}