var db = openDatabase("adadb", "1.0", "", 1000 );


//COOKIES
	function getCookie(cname) {
	    var name = cname + "=";
	    var decodedCookie = decodeURIComponent(document.cookie);
	    var ca = decodedCookie.split(';');
	    for(var i = 0; i <ca.length; i++) {
	        var c = ca[i];
	        while (c.charAt(0) == ' ') {
	            c = c.substring(1);
	        }
	        if (c.indexOf(name) == 0) {
	            return c.substring(name.length, c.length);
	        }
	    }
	    return "";
	}
//END OF COOKIES

//functions for sqlite
	//sqlite inserting user credentials table data 
		function insertToUserTable(uPass){
			db.transaction( function(tx){
				var status = tx.executeSql("INSERT INTO userCredentials(userPassword) VALUES(?)", [uPass], null,null);
			});
		}


	
	//sqlite Retrieve all mood tracker entries from local db
		function readAllMoodTrackerEntries(){
			db.transaction( function(tx){
				tx.executeSql("SELECT * FROM moodTrackerTbl", [], function(tx, results){
					var numRows = results.rows.length;
					
					if (numRows>0) {

						for(var i =0; i<numRows; i++){
							var row = results.rows.item(i);
						//storing values to variables
							var moodid = row['moodId'];
 							var imgPath = row['moodImg'];
							var moodContent = row['moodEntry'];
							var moodDate = row['moodDate'];
							var moodTime =  row['moodTime'];

							//console.log(moodid, imgPath, moodContent);

						//appending values to DOM
						$("#moodTrackerEntryCon").prepend('<li id=" ' + moodid + ' " class="messageLi"><a href="#" class="messageLink moodTrackerLink"><div class="messageDivMain"><img src=" ' + imgPath + ' " class="messageAvatar moodTrackerImg "><p class="messageAvatarName"> '+ moodDate +' </p><p class="messageExcerpt"> '+moodTime+' </p></div></a></li>');
						}

					}else{

					}

				});
			});
		}		

	//sqlite vaidate login
			function validateLogin(uPass){
				db.transaction( function(tx){
					tx.executeSql("SELECT userPassword FROM userCredentials WHERE userPassword = ?", [uPass], function( tx, results ){
						//get result lenght
						var numRows = results.rows.length;
						
						if (numRows> 0) {
							$("#notifLogin").html('<div class="alert alert-success" role="alert" style="margin: 30px 20px 0 20px">Login successful!</div>');
							document.cookie = "login = 1"
							setTimeout( function(){
								$("#offlineLogin").fadeOut();
								$("#offlineSignUp").hide();
								$("#mainConMoodTrack").slideDown();
								//alert(getCookie("login"));
							}, 1000);
						
						}else{
							$("#notifLogin").html('<div class="alert alert-danger" role="alert" style="margin: 30px 20px 0 20px">Login Failed!</div>');
						}


					});
				});
			}


			//sqlite this wll insert entry into the local database
			function insertToMoodTracker(moodimg, moodentry,mooddate,moodtime){
				db.transaction( function(tx){
					tx.executeSql("INSERT INTO moodTrackerTbl(moodImg, moodEntry, moodDate, moodTime) VALUES(?,?,?,?)", [moodimg, moodentry,mooddate,moodtime], 
						function(){
							var fff = $("#modalContent");
								fff.html("<img src='../img/loading.gif' style='width: 100px; height:100px; margin: 0 auto; display:block'>");
							setTimeout( function(){
								fff.html("<div style='display:block; margin:0 auto; color: green; text-align:center'><i class='glyphicon glyphicon-ok-sign' style='font-size: 50px; display:block; margin:0 auto'></i><p style=' display:block; margin:0 auto'>Successfully Saved!</p></div>")

								setTimeout( function(){
									$("#addEntryMoodTracker").slideUp();

									
										
										$("#modalContent").html('<form method="POST" id="addMoodForm"><label>Choose your mood:</label><center><div class="moodIconCon"><input type="radio" name="mood" class="moodIcon" value=""  id="mood1"><img src="img/1.png" style="height: 22px; width: 22px"></div><div class="moodIconCon"><input type="radio" name="mood" class="moodIcon" value="" id="mood2"><img src="img/2.png" style="height: 22px; width: 22px"></div><div class="moodIconCon"><input type="radio" name="mood" class="moodIcon" value="" id="mood3"><img src="img/3.png" style="height: 22px; width: 22px"></div><div class="moodIconCon"><input type="radio" name="mood" class="moodIcon" value="" id="mood4"><img src="img/4.png" style="height: 22px; width: 22px"></div><div class="moodIconCon"><input type="radio" name="mood" class="moodIcon" value="" id="mood5"><img src="img/5.png" style="height: 22px; width: 22px"></div></center><hr><textarea class="form-control" id="moodEntryText" style="" placeholder="Write Entry here.."></textarea><button class="btn btn-primary" type="submit" style="margin: 10px 5px 0 0; float: right;display: block" id="btnSubmitMood"><i class="glyphicon glyphicon-floppy-save"></i>Add Entry</button></form><br><br><hr><div id="errorNotif"></div>');
									},);


								

							},1500);

						});
				});
			}



$(document).ready( function(){


	$("#ofSignUpForm").submit( function(e){
		e.preventDefault();
		var pass1 = $("#pass1").val();
		var pass2 = $("#pass2").val();

		if (pass1 == pass2) {
			var status = insertToUserTable(pass1);
			var ele = $(this).parent().html('<div class="alert alert-success" role="alert" style="margin: 30px 20px 0 20px">Password has been saved successfully</div>');
			setTimeout( function(){
				$("#offlineLogin").slideDown();
			}, 2000);
		}else{
			//passwords did not match
			alert('Passwords did not match!');
		}
	});

	$("#ofLoginForm").submit( function(e){
		e.preventDefault();

		var upass = $("#loginPass").val();
		validateLogin(upass);
	});

	

	//add entry to mood tracker
	$("#addEntryMoodTracker").on('submit','#addMoodForm', function(noLoad){

		noLoad.preventDefault();


		var moodImg = $(this).find("input[name=mood]:checked").siblings('img').attr('src');

		//get current time
		var time = new Date();
		var mytime = time.toLocaleString('en-US', { hour: 'numeric', minute: 'numeric', hour12: true })
	
		//get date in month date, year format ex: january 1, 2018
		//get year
		var d = new Date();
		var year = d.getUTCFullYear();
		//get day of the month
		var d = new Date();
    	var day = d.getUTCDate();
 		//get month
 		var d = new Date();
	    var month = new Array(12);
	    month[0] = "January";
	    month[1] = "February";
	    month[2] = "March";
	    month[3] = "April";
	    month[4] = "May";
	    month[5] = "June";
	    month[6] = "July";
	    month[7] = "August";
	    month[8] = "September";
	    month[9] = "October";
	    month[10] = "November";
	    month[11] = "December";

	    var month = month[d.getUTCMonth()];

	    //concatinate date
	    var mydate = month + " " + day + ", " + year;

	    //fetching user entry in the textarea
	    var userEntry = $(this).find('textarea').val();

	    if (userEntry || moodImg) {
	    	//saving
	    	insertToMoodTracker(moodImg, userEntry,mydate,mytime);
	    	

	    	//prepend data to the list
	    	$("#moodTrackerEntryCon").prepend('<li id=" ' + 'moodid' + ' " class="messageLi"><a href="#" class="messageLink moodTrackerLink"><div class="messageDivMain"><img src=" ' + moodImg + ' " class="messageAvatar moodTrackerImg "><p class="messageAvatarName">' + mydate + '</p><p class="messageExcerpt"> ' + mytime + ' </p></div></a></li>');

	    }else{
	    	$("#errorNotif").html('<div class="alert alert-danger" role="alert"><span class="glyphicon glyphicon-remove"></span>Please complete all fields!</div>');
	    }
	    	
	
	});


	/////uncheking of radio buttons on filter
	$("#oldMoodEntriesListCon input[name=mood]").click( function(){
		
	}) ;
	    




});//end oof docu.ready
