
var db = openDatabase("adadb", "1.0", "", 1000 );

///////////////////////////////////////////////////////////////
//get year
				var d = new Date();
				var year = d.getUTCFullYear();
				//get day of the month
				var d = new Date();
		    	var day = d.getUTCDate()+1;
		 		//get month
		 		var d = new Date();
			    var month = new Array(12);
			    month[0] = "January";
			    month[1] = "February";
			    month[2] = "March";
			    month[3] = "April";
			    month[4] = "May";
			    month[5] = "June";
			    month[6] = "July";
			    month[7] = "August";
			    month[8] = "September";
			    month[9] = "October";
			    month[10] = "November";
			    month[11] = "December";

			    var month = month[d.getUTCMonth()];

			    //concatinate date
			    var mydate = month + " " + day + ", " + year;

				//get time
				var time = new Date();
				
				var cTime= time.toLocaleString('en-US', { hour: 'numeric', minute: 'numeric', hour12: true });


//////////////////////////////////////////////////////////////////


$(document).ready( function(){

	$("#startEvaluateBtn").click( function(){
		var This = $(this);
			This.html("Loading .");
		setTimeout( function(){
			This.html("Loading ..");
		}, 300);
		setTimeout( function(){
			This.html("Loading ...");
		}, 500);
		setTimeout( function(){
			This.html("Loading Complete!");
		}, 800);
		setTimeout( function(){
			$("#startPageEvaluation").slideUp('1000');
		}, 1300);

		setTimeout( function(){
			//display : block on questionpage
			$("#questionPage").fadeIn('500');
		}, 2000);
	});

	////////////////////////////////////////////////
	//evaluation chocices
	//changing attr of selected radio
	$("#choicesQuestionaire").on('click', '.phqChoiceBtn',  function(){
		//alert("choice has been clicked");
		$('input[name=phqChoices]').attr('checked', false);
		$('.phqChoiceBtn').removeClass('evaluationChoiceActive');
		$(this).siblings('input[name=phqChoices]').attr('checked', true);
		$(this).addClass('evaluationChoiceActive');
	});

	/////////////////////////////////////////////
	//submitting answers on the evaluation form
	//this will count the initial score and clear all choices and change the question
	$("#myChoices").submit( function(noLoad){
		noLoad.preventDefault();

		
		//check if radio button is chedcked
		var radio = $(this).find('input[name = phqChoices]:checked');
		var checkRadio =radio.val();

		if(checkRadio){
			//alert("a radio button has been checked");

			if(q_index == 8){
				//finish evaluation
				//aler t('eval finished');
				var r_value = parseInt( radio.attr('value'));
					totalScore = totalScore + r_value;
				var fScore = totalScore;
				var resultEqual = "";	//word equivalence of result
				var resultTip = "";	//tip for the result

				//fetch from mysqlite the equivalence of the total score;
				
				db.transaction( function(tx){
					tx.executeSql("SELECT * from evaluation_criteria WHERE evaluation_id = ?", [1], function(tx, results){

						var numRows = results.rows.length;
						console.log(numRows);

						for( var i = 0; i<numRows ; i++){
							var row = results.rows.item(i);
							var startV = parseInt(row['start_scope']);
							var endV = parseInt(row['end_scope']);

							if(fScore >= startV && fScore <= endV){
								resultEqual = row['result_equivalence'];
								console.log(resultEqual);
								resultTip = row['result_tip'];
								break;
							}else{
								console.log('not in range: ' + startV +" " + endV);
							}

						}


					});
				});

				
				$("#questionPage").slideUp('1000');
				setTimeout( function(){
					$("#viewResults").fadeIn();
					$(".resultCon").html('<img src="../img/loading.gif" style="width:100%">');
					setTimeout( function(){
						var resultBox = $(".resultCon")
							resultBox.html('<p><b id="result_score">'+fScore+'/27</b></p><div class="flw level" style=" min-height: 100px; border-radius: 5px "><h2 style="line-height: 50px" id="result_e"> '+ resultEqual+' </h2></div>');
						if(resultEqual == "None"){
							resultBox.find('.level').css({'background': '#45ff45', 'color':'white', 'box-shadow': '1px 1px 25px #45ff45'});

						}else if(resultEqual == "Mild Depression"){
							resultBox.find('.level').css({'background': 'rgb(226, 255, 69)', 'color':'white', 'box-shadow': '1px 1px 25px rgb(226, 255, 69)'});

						}else if(resultEqual == "Moderate Depression"){
							resultBox.find('.level').css({'background': 'rgb(255, 247, 0)', 'color':'white', 'box-shadow': '1px 1px 25px rgb(255, 247, 0)'});
						
						}else if(resultEqual == "Moderately Severe Depression"){
							resultBox.find('.level').css({'background': 'rgb(255, 198, 69)', 'color':'white', 'box-shadow': '1px 1px 25px rgb(255, 198, 69)'});
						
						}else if(resultEqual == "Severe Depression"){
							resultBox.find('.level').css({'background': 'rgb(185, 0, 0)', 'color':'white', 'box-shadow': '1px 1px 25px rgb(185, 0, 0)'});
						}

						////////////////////////
						//saving result to log
						db.transaction( function(tx){
							tx.executeSql("INSERT INTO evaluation_results(evaluation_id, result_total, result_equivalence, date_taken, time_taken ) VALUES(?,?,?,?,?)", [1, fScore, resultEqual, mydate, cTime], null, null);
						});

						setTimeout( function(){
							$(".tipBox .tips").html(resultTip);
							$(".tipBox").slideDown();
						}, 1000);

					}, 2000);
				},1200);

			}else{
				q_index = q_index + 1;
				var asd = $('.questionCon p');
				 			asd.parent().removeClass('animated bounce');
				 			setTimeout( function(){
				 				asd.html(questions[q_index]);
				 				asd.parent().addClass('animated bounce');

				 				//record checked radio box value
								var r_value = parseInt( radio.attr('value'));
								totalScore = totalScore + r_value;

								

								//changing the question count
								q_count = q_index + 1;
								$(".questionNumber").html(q_count);

								//changing count of progress bar
								var p =$("#pBar").width()/ $('#pBar').parent().width() * 100;
								var newWidth = p + 11.11;
									$("#pBar").width(newWidth + "%");
								//console.log(newWidth);

				 				//uncheck radioboxes
				 				$("#myChoices").find("input:radio").removeAttr('checked');
				 				$(".phqChoiceBtn").removeClass('evaluationChoiceActive');

				 			}, 100);
				
			}


			

			//this will check if the qCount == 9
			//if it is it will change the buttin next to finished
			//then stop the evaluation
			if(q_count == 8){
				//alert("asd");
				var btnSub = $("#btnSubmit button");
					btnSub.html('<i class="glyphicon glyphicon-ok"></i> Finish');
					btnSub.removeClass('btn-info');
					btnSub.addClass('btn-warning');
			}

			

		}else{
			//alert("no radio button has been checked")
		}

	});

	

});