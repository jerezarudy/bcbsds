

//toast notif

function toastNotif(message){
	var $notifDiv = $(".toastNotif .toastNotifContent");
		$notifDiv.html(message);
		$notifDiv.addClass("animated bounce");
		$notifDiv.parent().stop().fadeIn();

	setTimeout( function(){
		$notifDiv.parent().fadeOut();
		$notifDiv.removeClass("animated bounce");
	}, 2500);
}

//end of toast notif



//new custom modal function
(function( $ ){
   $.fn.customModal = function(action) {
   	var $this = $(this);
	 if(action === "show" || action == null){
	 	$this.fadeIn();
	 	setTimeout( function(){
	 		$this.find('.customModal-body').show().addClass('animated fadeInDown');
	 	}, 200);

	 }else if(action === "hide"){
	 	$this.fadeOut();
	 	setTimeout( function(){
	 		$this.css('display', 'none');
	 	}, 300);
	 }		

	return this;

   }; 
})( jQuery );
//close modals



/*end of post message*/

/*go to bottom jquery method*/
(function( $ ){
   $.fn.gotoBottom = function() {
   	var $this = $(this);
	 $this.animate({scrollTop: $this.get(0).scrollHeight}, 100); 

	return this;

   }; 
})( jQuery );
/*end of go to bottom*/


//////////////////////////////////
function getMonthName(month){
	switch(month){
		case 0:
			return 'January';
			break;
		case 1:
			return 'February';
			break;
		case 2:
			return 'March';
			break;
		case 3:
			return 'April';
			break;
		case 4:
			return 'May';
			break;
		case 5:
			return 'June';
			break;
		case 6:
			return 'July';
			break;
		case 7:
			return 'August';
			break;
		case 8:
			return 'September';
			break;
		case 9:
			return 'October';
			break;
		case 10:
			return 'November';
			break;
		case 11:
			return 'December';
			break;
	}
}

function getDateTime(){
	var currentdate = new Date(); 
	var a = 'AM';
	if(Number(currentdate.getHours())> 12){
		a = 'PM';
	}
    var datetime = currentdate.getDate() + "/"
                + (currentdate.getMonth()+1)  + "/" 
                + currentdate.getFullYear() + " "  
                + currentdate.getHours() + ":"  
                + currentdate.getMinutes() + ":" 
                + currentdate.getSeconds() 
                + ' ' + a;

return(datetime);
}

function getDateOnly(){
	var currentdate = new Date(); 
	
    var datetime = currentdate.getDate() + "/"
                + (currentdate.getMonth()+1)  + "/" 
                + currentdate.getFullYear();

return(datetime);
}