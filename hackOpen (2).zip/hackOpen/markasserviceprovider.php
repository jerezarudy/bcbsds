<html>
<?php
include "dbConfig.php";
session_start();
$id = $_SESSION['session_id'];
$rid = $_GET['rid'];
if($_SESSION['session_id']==true){
?>
<head>
<title>BCBSDS</title>
<script src="js/jquery.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/dataTables.min.js" defer="true"></script>
<script src="js/dataTables.responsive.min.js" defer="true"></script>
<script src="js/dataTables.rowReorder.min.js" defer="true"></script>

<link rel="stylesheet" href="css/bootstrap.css"/>
<link rel="stylesheet" href="css/akun.css"/>
<link rel="stylesheet" href="css/dataTables.min.css"/>
<link rel="stylesheet" href="css/responsive.dataTables.min.css"/>
<link rel="stylesheet" href="css/rowReorder.dataTables.min.css"/>

</head>


<body>
	<div class="side">
		<img src="img/logo b.png"/>
		
		<div class="sidenavv">
		<hr style="margin-bottom: 37px;">
			<ul class="pililian">
				<a href="admin.php" style="text-decoration: none;"><li><i class="glyphicon glyphicon-home"></i> Home</li></a>
				<a href="listresidence.php" style="text-decoration: none;"><li class="activee"><i class="glyphicon glyphicon-list"></i> List of Residents</li></a>
				<a href="listserviceprovider.php" style="text-decoration: none;"><li><i class="glyphicon glyphicon-list"></i> List of Service Providers</li></a>
				<a href="addservices.php" style="text-decoration: none;"><li><i class="glyphicon glyphicon-plus"></i> Add Services</li></a>
				<a href="activehiring.php" style="text-decoration: none;"><li class=""><i class="glyphicon glyphicon-book"></i> View Active Hirings</li></a>
			</ul>
			<a href="logout.php" style="text-decoration: none;color: #fff; "><div class="loooog"><i class="glyphicon glyphicon-log-out"></i> Logout
			</div></a>
		</div>
	</div>
	<div class="headdd">
		
		
	</div>
	<div class="lawas">
		<div class="titlee">
		Service Provider 
		</div>
		<div class="contentt">
		
			<div class="col-md-4">
			<?php
				$res = mysqli_query($con,"Select * from customer where id = '$rid'");
				$data = mysqli_fetch_object($res);
			?>
			
			<center><img src="<?php echo $data->user_image; ?>"  class="img-circle" alt="User Image" style="width:200px; height:200px;" />
			<h3><?php echo $data->f_name." ".$data->m_name." ".$data->l_name; ?></h3>
			<?php echo $data->phone_number; ?><br>
			<?php echo $data->sex; ?><br>
			<?php echo $data->user_address; ?>
			</center>
			</div>
			<div class="col-md-8">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Services List</h3>
			  <?php
							if(isset($_POST['submit'])){
								
								
							$service = $_POST['service'];
							$rate = $_POST['rate'];
							

							
						
								$query = "INSERT INTO `s_provider`(`userid`, `work_rate`, `service`,`status`) VALUES('$rid','$rate','$service','Available')";
								$ros = mysqli_query($con,$query);
								
								if($ros ==true){
									?>
									<div class="alert alert-info">
										  <button class="close" data-dismiss="alert">�</button>
										  <strong>Saved!</strong> Data Inserted!. </div>
									<?php
									
								}
								
							}

										
							?>
			  <form method="POST">
				<select name="service" required class="form-control">
				<?php
					$res1 = mysqli_query($con,"Select * from category_services");
					while($data1 = mysqli_fetch_object($res1)):
				?>
					<option selected hidden value="">--Select--</option>
					<option value="<?php echo $data1->id; ?>"><?php echo $data1->service_name; ?></option>
					<?php
					endwhile;
					?>
				</select>
				<h4>Rate per Day:</h4>
				<input type="number" name="rate" class="form-control"/><br>
				<a href="listresidence.php" style="float:right;" class="btn btn-default">Cancel</a>
				<input type="submit" name="submit" style="float:right; margin-right:5px;" class="btn btn-success" value="Add Service"/>
				</form>
            </div>
			<br>
			<br>
            <!-- /.box-header -->
            <div class="box-body">
			<div style="overflow-x:auto;">
			
               <table id="" class="table table-bordered table-striped">
                <thead>
					<tr>
					  <th>Services</th>
					  <th>Rate per Day</th>
					  <th>Actions</th>
					</tr>
				</thead>
				<tbody>
                <?php 
				$result2 = mysqli_query($con,"SELECT * FROM s_provider as A INNER JOIN category_services as B on A.service = B.id where userid= $rid");
				while($data2 = mysqli_fetch_object($result2)):

			  ?>
				
					<tr>
					
					  
					  <td><?php echo $data2->service_name; ?></td>
					  <td><?php echo $data2->work_rate; ?></td>
					  <td><a href="updatestud.php?id=<?php echo $data->stud_id; ?>" ><button type="button" class="btn btn-sm btn-info"><i class="glyphicon glyphicon-pencil"></i></button></a> <a href="deleteservices.php?sid=<?php echo $data->id; ?>" onclick="return confirm('Do you want to delete this resident?')" ><button type="button" class="btn btn-sm btn-danger"><i class="glyphicon glyphicon-trash"></i></button></a>
					  </td>
					</tr>
				
                 <?php
				endwhile;
				
					?>
				</tbody>
              </table>
			  <script type="text/javascript" defer="true">
				$(document).ready( function(){
				var table = $('#example1').DataTable({
					rowReorder:{
						selector: 'td:nth-child(2)'
					},
					responsive:true
						});
				});
			  </script>
			  </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
      
        <!-- /.box-body -->

        <!-- /.box-footer-->
						</div>
			
		</div>
	</div>
	
</body>
<?php
}
else{
header('Location:index.php');
}
?>
</html>