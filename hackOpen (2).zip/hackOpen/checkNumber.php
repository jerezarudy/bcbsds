<?php
	require 'dbConfig.php';
	include ( "src/NexmoMessage.php" );
	$number = $_POST['pnumber'];
	$userId;

	$query = "SELECT * FROM customer WHERE phone_number='$number'";
	$exeQuery = mysqli_query($con, $query);

	if(mysqli_num_rows($exeQuery) == 1){
		$get = mysqli_fetch_array($exeQuery);
		//phone number is present in db
		//create new verification code
		//verification code is 4 number digit
		$verCode = mt_rand(1000, 9999);
		 

		//send verification code to user via sms here
		$nexmo_sms = new NexmoMessage('3fd2f58d', 'jsLMlGV016O3OZSt');

		// Step 2: Use sendText( $to, $from, $message ) method to send a message. 
		$info = $nexmo_sms->sendText( $get['phone_number'], 'GwapoRudy', 'Your Verification Code: '.$verCode);


		//save verification code to database
		$userId = $get['id'];
		$query = "INSERT INTO verficationcode(code, customer_id, status) VALUES('$verCode', '$userId', 'pending')";
		$exeQuery = mysqli_query($con, $query);
		if($exeQuery == false){
			$userId = 'null';
		}
	}else{
		$userId = 'null';
	}

	echo json_encode(
		array(
			'id' => $userId
		)

	);

	mysqli_close($con);
?>