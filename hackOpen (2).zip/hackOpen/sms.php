<?php
	include 'dbConfig.php';
?>

<!DOCTYPE html>
<html>
<head>
	<title>hackOpen</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>

	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/animate.css">
	<link rel="stylesheet" type="text/css" href="css/custom.css">


</head>
<body>
	<header class="msgHeader">
		System name

	
	</header>
		
	<main>

		<ul id="msgThread">

			<?php
				$query = "SELECT * FROM messages WHERE sender_id = '1' AND sender_brgy_id = '1' ORDER BY msg_dateTime ASC";
				$exeQuery = mysqli_query($con, $query);
				if(mysqli_num_rows($exeQuery) == 0){
					echo '<script>alert("asd")</script>';
				}
				while ($get = mysqli_fetch_array($exeQuery)): 
			?>
				<li class="threadCon">
					<div class="msgBody <?php echo $get['msg_type']?>">
						<?php echo  $get['msg_content']; ?>
						<br>
						<?php echo  $get['msg_dateTime']; ?>
					</div>
				</li>
			<?php endwhile; ?>

		</ul>

	</main>
	<footer class="msgFooter">
		<form id="frmMessage" method="POST">
			<textarea class="form-control" placeholder="Enter message"></textarea>
			<div style="display: inline-block; float: right;">
				<button type="submit" id="btnSubmitMsg" class="btn btn-primary">
					SEND
				</button>
			</div>
		</form>
	</footer>

	<script type="text/javascript" defer="true">
		$(document).ready( function(){

			$('#frmMessage').submit( function(event){
				event.preventDefault();
				var data = $(this).serializeArray();
				var url = "http://localhost/hackOpen/sendMessage.php";

			})

		})

	</script>

</body>
</html>