<html>
<?php
include "dbConfig.php";
session_start();
$id = $_SESSION['session_id'];
if($_SESSION['session_id']==true){
?>
<head>
<title>BCBSDS</title>
<script src="js/jquery.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/dataTables.min.js" defer="true"></script>
<script src="js/dataTables.responsive.min.js" defer="true"></script>
<script src="js/dataTables.rowReorder.min.js" defer="true"></script>

<link rel="stylesheet" href="css/bootstrap.css"/>
<link rel="stylesheet" href="css/akun.css"/>
<link rel="stylesheet" href="css/dataTables.min.css"/>
<link rel="stylesheet" href="css/responsive.dataTables.min.css"/>
<link rel="stylesheet" href="css/rowReorder.dataTables.min.css"/>

</head>


<body>
	<div class="side">
		<img src="img/logo b.png"/>
		
		<div class="sidenavv">
		<hr style="    margin-bottom: 37px;">
			<ul class="pililian">
				<a href="admin.php" style="text-decoration: none;"><li><i class="glyphicon glyphicon-home"></i> Home</li></a>
				<a href="listresidence.php" style="text-decoration: none;"><li class="activee"><i class="glyphicon glyphicon-list"></i> List of Residents</li></a>
				<a href="listserviceprovider.php" style="text-decoration: none;"><li><i class="glyphicon glyphicon-list"></i> List of Service Providers</li></a>
				<a href="addservices.php" style="text-decoration: none;"><li><i class="glyphicon glyphicon-plus"></i> Add Services</li></a>
				<a href="activehiring.php" style="text-decoration: none;"><li class=""><i class="glyphicon glyphicon-book"></i> View Active Hirings</li></a>
			</ul>
			<a href="logout.php" style="text-decoration: none;color: #fff; "><div class="loooog"><i class="glyphicon glyphicon-log-out"></i> Logout
			</div></a>
		</div>
	</div>
	<div class="headdd">
		
		
	</div>
	<div class="lawas">
		<div class="titlee">
		List of Residents
		</div>
		<div class="contentt">
			<button class="btn btn-default" style="margin-left:15px;margin-bottom:10px;" data-toggle="modal" data-target="#modal-success">Add Resident</button>

			<div class="col-md-12">
					
					<div class="panel">
						<?php
							if(isset($_POST['save'])){
								
								
							$fname = $_POST['fname'];
							$mname = $_POST['mname'];
							$lname = $_POST['lname'];
							$dob = $_POST['dob'];
							$sex = $_POST['sex'];
							$cn = $_POST['cn'];
							$address = $_POST['address'];

							
								$pic =$_FILES['pic']['name'];
								$dst = "./residentimages/".$pic;
								move_uploaded_file($_FILES['pic']['tmp_name'],$dst);
								$query = "INSERT INTO `customer`(`brgy_id`, `l_name`, `f_name`, `m_name`, `phone_number`, `sex`, `user_address`, `birthdate`, `user_image`) VALUES('$id','$lname','$fname','$mname','$cn','$sex','$address','$dob','$dst')";
								$ros = mysqli_query($con,$query);
								
								if($ros ==true){
									?>
									<div class="alert alert-info">
										  <button class="close" data-dismiss="alert">�</button>
										  <strong>Saved!</strong> Data Inserted!. </div>
									<?php
									
								}
								
							}

										
							?>	
						<div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Student's List</h3>

            </div>
            <!-- /.box-header -->
            <div class="box-body">
			<div style="overflow-x:auto;">
			
               <table id="example1" class="table table-bordered table-striped">
                <thead>
					<tr>
					  <th>Resident Image</th>
					  <th>Resident Name</th>
					  <th>Cellphone Number</th>
					  <th>Sex</th>
					  <th>Address</th>
					  <th>Birthdate</th>
					  <th>Actions</th>
					</tr>
				</thead>
				<tbody>
                <?php 
				$result = mysqli_query($con,"SELECT * FROM customer where `brgy_id` = '$id'");
				while($data = mysqli_fetch_object($result) ):

			  ?>
				
					<tr>
					<td><img src="<?php echo $data->user_image; ?>"  class="img-circle" alt="User Image" style="width:40px; height:40px;"></td>
					  <td ><?php echo $data->l_name; ?>, <?php echo $data->f_name; ?> <?php echo $data->m_name; ?></td>
					  <td><?php echo $data->phone_number; ?></td>
					  <td><?php echo $data->sex; ?></td>
					  <td><?php echo $data->user_address; ?></td>
					  <td><?php echo $data->birthdate; ?></td>
					  <td><a href="updatestud.php?id=<?php echo $data->stud_id; ?>" ><button type="button" class="btn btn-sm btn-info"><i class="glyphicon glyphicon-pencil"></i></button></a> <a href="deleteresident.php?rid=<?php echo $data->id; ?>" onclick="return confirm('Do you want to delete this resident?')" ><button type="button" class="btn btn-sm btn-danger"><i class="glyphicon glyphicon-trash"></i></button></a><br>
					  <a href="markasserviceprovider.php?rid=<?php echo $data->id; ?>" ><button type="button" class="btn btn-sm btn-success" style="margin-top:5px;">Mark as Service Provider</button></a>
					  </td>
					</tr>
				
                 <?php
				endwhile;
				
					?>
				</tbody>
              </table>
			  <script type="text/javascript" defer="true">
				$(document).ready( function(){
				var table = $('#example1').DataTable({
					rowReorder:{
						selector: 'td:nth-child(2)'
					},
					responsive:true
						});
				});
			  </script>
			  </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
      
        <!-- /.box-body -->
        <div class="box-footer">
   
        </div>
        <!-- /.box-footer-->
      </div>
					</div>
				
			</div>
			
			
		</div>
	</div>
	<div class="modal fade" id="modal-success">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Add Resident</h4>
              </div>
              <div class="modal-body">
                 <form role="form" action="" method="POST" enctype="multipart/form-data">
              <div class="box-body">

                
                <div class="form-group">
                   <label for="exampleInputEmail1">Name</label>
                <div class="form-group" style="display:inline-flex">
                  
                  <input type="text" class="form-control" id="exampleInputEmail1" style="width:33%;" placeholder="Enter First Name" name="fname" required>
               
                
                  <input type="text" class="form-control" id="exampleInputEmail1" style="width:33%;    margin-left: 15px;" placeholder="Enter Middle Name" name="mname" required>
                
                  
                  <input type="text" class="form-control" id="exampleInputEmail1" style="width:33%;    margin-left: 15px;" placeholder="Enter Last Name" name="lname" required>
                </div>
				<div class="form-group">
                  <label for="exampleInputEmail1">Sex</label>
                  <select class="form-control" name="sex" required>
					<option value="" selected hidden>--Select--</option>
					<option value="Male">Male</option>
					<option value="Female">Female</option>
				  </select>
                </div>
				<div class="form-group">
                  <label for="exampleInputEmail1">Date of Birth</label>
                  <input type="date" class="form-control" id="exampleInputEmail1" placeholder="Enter Cellphone Number" name="dob" required>
                </div>
				<div class="form-group">
                  <label for="exampleInputEmail1">Cellphone Number</label>
                  <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter Cellphone Number" name="cn" required>
                </div>
				<div class="form-group">
                  <label for="exampleInputEmail1">Address</label>
                  <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter Address" name="address" required>
                </div>
				<div class="form-group">
                  <label for="exampleInputFile">Resident Image</label>
                  <input type="file" id="exampleInputFile" name="pic" required/>

                  
                </div>

                  
                </div>
                
              </div>
              <!-- /.box-body -->

          
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <input type="submit" class="btn btn-primary" name="save" value="Save">
                  </form>
              </div>
              
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
</body>
<?php
}
else{
header('Location:index.php');
}
?>
</html>