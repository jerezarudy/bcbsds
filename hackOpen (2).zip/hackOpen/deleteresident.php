<?php
include "dbConfig.php";
session_start();

$rid = $_GET['rid'];
mysqli_query($con,"Delete from customer where id = $rid");
header("Location:listresidence.php");
?>