<html>
<?php
include "dbConfig.php";
session_start();
$id = $_SESSION['session_id'];
if($_SESSION['session_id']==true){
?>
<head>
<title>BCBSDS</title>
<link rel="stylesheet" href="css/bootstrap.css"/>
<link rel="stylesheet" href="css/akun.css"/>
</head>


<body>
	<div class="side">
		<img src="img/logo b.png"/>
		
		<div class="sidenavv">
		<hr style="    margin-bottom: 37px;">
			<ul class="pililian">
				<a href="admin.php" style="text-decoration: none;"><li class=""><i class="glyphicon glyphicon-home"></i> Home</li></a>
				<a href="listresidence.php" style="text-decoration: none;"><li><i class="glyphicon glyphicon-list"></i> List of Residents</li></a>
				<a href="listserviceprovider.php" style="text-decoration: none;"><li><i class="glyphicon glyphicon-list"></i> List of Service Providers</li></a>
				<a href="addservices.php" style="text-decoration: none;"><li class="activee"><i class="glyphicon glyphicon-plus"></i> Add Services</li></a>
				<a href="activehiring.php" style="text-decoration: none;"><li class=""><i class="glyphicon glyphicon-book"></i> View Active Hirings</li></a>
				
			</ul>
			<a href="logout.php" style="text-decoration: none;color: #fff; "><div class="loooog"><i class="glyphicon glyphicon-log-out"></i> Logout
			</div></a>
		</div>
	</div>
	<div class="headdd">
		
		
	</div>
	<div class="lawas">
		<div class="titlee">
		Services
		</div>
		<div class="contentt">
			

			<div class="col-md-6">
					<div class="panel">
						<?php
							if(isset($_POST['save'])){
								
								
							$service = $_POST['service'];
							$servicedesc = $_POST['servicedesc'];
							

							
						
								$query = "INSERT INTO `category_services`(`service_name`,`service_desc`) VALUES('$service','$servicedesc')";
								$ros = mysqli_query($con,$query);
								
								if($ros ==true){
									?>
									<div class="alert alert-info">
										  <button class="close" data-dismiss="alert">�</button>
										  <strong>Saved!</strong> Data Inserted!. </div>
									<?php
									
								}
								
							}

										
							?>	
						<div class="form-group">
                 
               
				
					<div class="form-group">
					<form method="POST">
					  <label for="exampleInputEmail1">Service Name</label>
					  <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter Service Name" name="service" required>
					  <label for="exampleInputEmail1">Service Description</label>
					  <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter Service Description" name="servicedesc" required>
					</div>
					<input type="submit" class="btn btn-primary" name="save" value="Save">
					</form>

                  
						</div>
					</div>
				
			</div>
			<div class="col-md-6">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Services List</h3>

            </div>
            <!-- /.box-header -->
            <div class="box-body">
			<div style="overflow-x:auto;">
			
               <table id="example1" class="table table-bordered table-striped">
                <thead>
					<tr>
					  <th>Services Name</th>
					  <th>Actions</th>
					</tr>
				</thead>
				<tbody>
                <?php 
				$result = mysqli_query($con,"SELECT * FROM category_services");
				while($data = mysqli_fetch_object($result) ):

			  ?>
				
					<tr>
					
					  
					  <td><?php echo $data->service_name; ?></td>
					  <td><a href="updatestud.php?id=<?php echo $data->stud_id; ?>" ><button type="button" class="btn btn-sm btn-info"><i class="glyphicon glyphicon-pencil"></i></button></a> <a href="deleteservices.php?sid=<?php echo $data->id; ?>" onclick="return confirm('Do you want to delete this resident?')" ><button type="button" class="btn btn-sm btn-danger"><i class="glyphicon glyphicon-trash"></i></button></a>
					  </td>
					</tr>
				
                 <?php
				endwhile;
				
					?>
				</tbody>
              </table>
			  <script type="text/javascript" defer="true">
				$(document).ready( function(){
				var table = $('#example1').DataTable({
					rowReorder:{
						selector: 'td:nth-child(2)'
					},
					responsive:true
						});
				});
			  </script>
			  </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
      
        <!-- /.box-body -->

        <!-- /.box-footer-->
						</div>
			
		</div>
		
	</div>


</body>

<?php
}
else{
header('Location:index.php');
}
?>
</html>